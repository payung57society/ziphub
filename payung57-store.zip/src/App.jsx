import React, { useState } from 'react'

const BRAND = {
  name: 'PAYUNG57 SOCIETY',
  accent1: '#00FF66',
  accent2: '#FF2AA8',
}

const PRODUCTS = [
  {
    id: 'payung-figure-1',
    title: '1/7 Scale PAYUNG57 Figure - Banjir Sccater',
    price: 89.99,
    image: 'https://via.placeholder.com/420x560.png?text=PAYUNG57+Figure',
    description: 'Highly detailed painted PVC figure, 1/7 scale. Limited production run.',
  },
  {
    id: 'payung-tee-1',
    title: 'PAYUNG57 T-Shirt',
    price: 24.99,
    image: 'https://via.placeholder.com/420x420.png?text=PAYUNG57+Tee',
    description: 'Comfort cotton tee — neon green & fuchsia print.',
  },
]

export default function App() {
  const [cart, setCart] = useState([])
  const [drawerOpen, setDrawerOpen] = useState(false)

  function addToCart(product) {
    setCart(c => {
      const existing = c.find(i => i.id === product.id)
      if (existing) {
        return c.map(i => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i))
      }
      return [...c, { ...product, qty: 1 }]
    })
    setDrawerOpen(true)
  }

  function updateQty(id, qty) {
    setCart(c =>
      c.map(i => (i.id === id ? { ...i, qty: Math.max(0, qty) } : i)).filter(i => i.qty > 0)
    )
  }

  function removeItem(id) {
    setCart(c => c.filter(i => i.id !== id))
  }

  const subtotal = cart.reduce((s, it) => s + it.price * it.qty, 0)

  function handleCheckout() {
    alert('Demo only — integrate Stripe or your payment gateway here.')
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <div className="w-full bg-gradient-to-r from-pink-500 to-green-400 text-white py-2 text-center font-semibold">
        Selamat datang di {BRAND.name} — Preorder Figure & Merch available!
      </div>

      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
            style={{ background: `linear-gradient(135deg, ${BRAND.accent2}, ${BRAND.accent1})` }}
          >
            P57
          </div>
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">{BRAND.name}</h1>
            <p className="text-sm text-gray-600">Collectible figures • Limited edition</p>
          </div>
        </div>

        <button
          onClick={() => setDrawerOpen(true)}
          className="relative inline-flex items-center gap-2 px-4 py-2 border rounded-md shadow-sm hover:shadow-lg"
        >
          Cart
          {cart.length > 0 && (
            <span className="ml-2 inline-block bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{cart.reduce((s,i)=>s+i.qty,0)}</span>
          )}
        </button>
      </header>

      <main className="max-w-6xl mx-auto px-6 pb-24">
        <section id="products" className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PRODUCTS.map(p => (
            <article key={p.id} className="bg-white rounded-2xl shadow p-4">
              <div className="aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
                <img src={p.image} alt={p.title} className="object-cover w-full h-full" />
              </div>
              <div className="mt-4 flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{p.title}</h3>
                  <p className="text-sm text-gray-600">{p.description}</p>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold">${p.price.toFixed(2)}</div>
                  <button
                    onClick={() => addToCart(p)}
                    className="mt-2 inline-block px-3 py-2 rounded-md text-white font-medium"
                    style={{ background: BRAND.accent2 }}
                  >
                    Add
                  </button>
                </div>
              </div>
            </article>
          ))}
        </section>

        <section id="about" className="mt-12 bg-white rounded-2xl shadow p-6">
          <h2 className="text-xl font-semibold">Tentang PAYUNG57 SOCIETY</h2>
          <p className="mt-2 text-gray-600">Brand independen yang menggabungkan style neon dan desain playful. Preorder figure dan merch, kualitas produksi terbatas.</p>
        </section>

        <footer id="contact" className="mt-8 text-center text-sm text-gray-600">
          <p>Questions? Email: hello@payung57.example</p>
          <p className="mt-2">© {new Date().getFullYear()} {BRAND.name}</p>
        </footer>
      </main>

      <div className={`fixed top-0 right-0 h-full w-full md:w-96 bg-white shadow-2xl transform ${drawerOpen ? 'translate-x-0' : 'translate-x-full'} transition-transform duration-300`}>
        <div className="p-4 flex items-center justify-between border-b">
          <h3 className="text-lg font-semibold">Cart</h3>
          <div className="flex items-center gap-2">
            <div className="text-sm text-gray-500">Subtotal: ${subtotal.toFixed(2)}</div>
            <button onClick={() => setDrawerOpen(false)} className="px-3 py-1">Close</button>
          </div>
        </div>
        <div className="p-4 overflow-auto" style={{ maxHeight: '70vh' }}>
          {cart.length === 0 ? (
            <div className="text-gray-500">Keranjang kosong.</div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex items-center gap-3 border-b py-3">
                <img src={item.image} alt={item.title} className="w-16 h-16 object-cover rounded" />
                <div className="flex-1">
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-gray-500">${item.price.toFixed(2)}</div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex items-center gap-1">
                    <button onClick={() => updateQty(item.id, item.qty - 1)} className="px-2">-</button>
                    <div className="px-2">{item.qty}</div>
                    <button onClick={() => updateQty(item.id, item.qty + 1)} className="px-2">+</button>
                  </div>
                  <button onClick={() => removeItem(item.id)} className="text-sm text-red-600">Remove</button>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="p-4 border-t">
          <div className="flex items-center justify-between mb-4">
            <div className="text-sm text-gray-500">Total</div>
            <div className="text-lg font-bold">${subtotal.toFixed(2)}</div>
          </div>
          <button onClick={handleCheckout} className="w-full py-3 rounded-md text-white font-semibold" style={{ background: BRAND.accent2 }}>
            Checkout
          </button>
        </div>
      </div>

      <button
        className="fixed bottom-6 right-6 md:hidden bg-pink-500 text-white p-3 rounded-full shadow-lg"
        onClick={() => setDrawerOpen(true)}
      >
        Cart
      </button>
    </div>
  )
}
